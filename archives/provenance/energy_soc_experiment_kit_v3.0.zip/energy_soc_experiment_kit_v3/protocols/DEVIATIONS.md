# Deviations log

Record here any change to `experiment_A_payload.json` or `experiment_B_fleet.json` made after the first confirmatory run,
any rerun outside the documented resume procedure, and any excluded run. For each entry give: date, protocol id, what
changed, why, and which results it affects. Report results under the original protocol as well.

| Date | Protocol | Change | Reason | Affected results |
| --- | --- | --- | --- | --- |
| (none yet) | | | | |
