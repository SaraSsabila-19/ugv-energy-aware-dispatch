# What was tested before delivery, and what was not

The kit was tested on the author's machine: Linux x86-64 cloud VM with 2 cores, CPython 3.13.18, numpy 2.4.6, scipy 1.17.1, networkx 3.6.1, osmnx 2.1.0, pandas 3.0.3, fastapi 0.137.0, pydantic 2.13.4, httpx 0.28.1, scikit-learn 1.9.0 and matplotlib 3.11.2. Your recorded environment is CPython 3.14.4.

## Verified

1. **Frozen source.** `app.py` is never modified. Every run archives `backend_source.py` with SHA-256 `7b52bb55…0a0`, and the validator re-checks it.
2. **Exact regression against your campaign.** 16 conditions of the 320-run energy weight × SOC campaign were rerun with the v3 runner and the probe on: seeds 30001 and 45001 × Hungarian and Greedy × 100% and 25% SOC × αE 0 and 1. All were byte-identical in `run_summary`, energy feasibility, request results, wait diagnostics, pool energy and vehicle results (timing columns excluded), and had identical workload hashes.
   - The comparison was against my independent rerun of your campaign. That rerun had already matched every number in your summary exactly.
   - These seeds had trial indices 29 and 44 in v2 but 20 in v3, so trial-index independence is also confirmed.
3. **Probe non-interference.** Runs with the probe reproduce runs without it, including all energy-blocking counters at 25% SOC. The planned energy of the chosen insertions equals battery withdrawal within 10⁻⁸ % in every probed run (over 200 runs, all configurations).
4. **Overrides.** Payload masses reach both prediction and execution, appear in `run_settings.json`, and are recorded in `overrides_and_provenance.json`. Energy per km changes as the motion model predicts (`bin/physics.py`).
5. **New configurations.** 24 UGVs / 200 requests runs as a registered scenario. 12 and 24 UGVs with 100 requests receive identical request sets for the same seed. Vehicles spread over the three depots.
6. **Full pipeline.** Launch, validate (all ten checks PASS), extract, analyze, figures, archive and archive verification on:
   - a 60-run miniature of Experiment A (seeds 905001–907001, all 36 contrasts);
   - a 72-run miniature of Experiment B (seeds 908001–910001, all 30 contrasts);
   - the 4-run tiny protocol, through `scripts/02_run_experiment.sh`.

   The exact sign-flip test was exercised on integer and half-integer (200-request) lattices, and Holm and the verdict rules were exercised in every family. Figures were inspected visually and their layout corrected.
7. **Safety.**
   - Refusal to write into a non-empty foreign folder.
   - Forced failures (1-second timeout) detected and recorded in `RUN_FAILED.json`.
   - Resume moves failed and interrupted attempts to `_incomplete/` without deleting them.
   - Finished runs are skipped.
   - A second launcher on the same campaign is refused (file lock).
   - SIGTERM or Ctrl-C stops running simulations, marks them "interrupted by user", leaves no orphan processes and exits 130.
   - A changed byte inside an export zip is detected by `archive.py --verify`.
8. **User-facing scripts, run from a fresh copy of the kit** with paths supplied through environment variables: `00_check_environment.sh`, `tests/selftest.sh` (all six steps), `01_smoke_and_regression.sh` (16 regression and 22 smoke runs, 0 differences) and `02_run_experiment.sh tests/selftest_tiny.json`. The graph-file fallback (`utp_graph.graphml.xml`) was exercised.
9. **Sample size.** `bin/sample_size.py` reproduces the protocols' variance-based numbers from the 320-run campaign layout.
10. **Paths.** No `/home/claude` path remains anywhere in the kit. Defaults in `scripts/config.sh` point to your folders, and all can be overridden.

## Not verified

1. **Your machine.** Exact reproduction of the new configurations (payload overrides, 24/200 scenario, probe) on CPython 3.14.4. Frozen configurations already matched between 3.13 and 3.14 in the 320-run campaign. `01_smoke_and_regression.sh` tests both on your machine; run it first.
2. **The default paths** `/home/sara/...`. They could not exist here. The scripts were run with the same variables pointing elsewhere.
3. **Full campaigns.** The 2,000-run and 960-run campaigns were not run: confirmatory seeds were deliberately not executed, so no confirmatory outcome has been seen. Runtime and disk figures are extrapolated from about 250 test runs.
4. **Long-run behaviour.** Behaviour under disk-full conditions, a power loss during a file write (outputs are written by the simulator; `RUN_OK.json` is written atomically last), and parallel jobs above 2 (logic is identical; not timed).
5. **Matplotlib 3.11.1.** The README pins 3.11.1 to match your original environment snapshot; the tests used 3.11.2.
6. **Interpretation.** Nothing here establishes the physical accuracy of the energy model or external validity beyond the campus network.
